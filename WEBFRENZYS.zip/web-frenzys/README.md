# WEB FRENZYS

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/preksh-monnappakm-jain-bca/pen/019cf278-847d-7def-8cc4-0d857f75901a](https://codepen.io/editor/preksh-monnappakm-jain-bca/pen/019cf278-847d-7def-8cc4-0d857f75901a).

